﻿

namespace Savi_Thrift.Application.DTO.Wallet
{
    public class CreditResponseDto
    {
        public string WalletNumber { get; set; }
        public decimal Balance { get; set; }
        public string Message { get; set; }
    }
}
