﻿namespace Savi_Thrift.Application.DTO.AppUser
{
	public class LoginResponseDto
	{
		public string JWToken { get; set; }
	}
}
