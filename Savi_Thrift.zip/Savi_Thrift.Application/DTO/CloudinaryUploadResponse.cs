﻿

namespace Savi_Thrift.Application.DTO
{
    public class CloudinaryUploadResponse
    {
        public string PublicId { get; set; }

        public string Url { get; set; }
    }
}
