﻿using Savi_Thrift.Application.DTO.Wallet;
using Savi_Thrift.Domain.Entities;
using TicketEase.Domain;

namespace Savi_Thrift.Application.Interfaces.Services
{
    public interface IWalletService
	{
		Task<ApiResponse<bool>> CreateWallet(CreateWalletDto createWalletDto);
		Task<ApiResponse<List<WalletResponseDto>>> GetAllWallets();
        Task<ApiResponse<Wallet>> GetWalletByNumber(string phone);
		Task<ApiResponse<CreditResponseDto>> FundWallet(FundWalletDto fundWalletDto);

    }
}
