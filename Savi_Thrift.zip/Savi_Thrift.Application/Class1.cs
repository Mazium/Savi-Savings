﻿namespace Savi_Thrift.Application
{
    public class Class1
    {

    }
}