﻿namespace Savi_Thrift.Infrastructure
{
    public class Class1
    {

    }
}