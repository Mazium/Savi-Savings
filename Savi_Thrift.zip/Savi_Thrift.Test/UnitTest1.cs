namespace Savi_Thrift.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}