﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Savi_Thrift.Domain.Enums
{
	public enum IdentificationType
	{
		Passport, 
		DriversLicense,
		NationalID,
		SocialSecurity,
		VotersID,
		ResidentialPermit,
		MilitaryID,
		HealthCard,
		WorkID,
		StudentID
	}
}
