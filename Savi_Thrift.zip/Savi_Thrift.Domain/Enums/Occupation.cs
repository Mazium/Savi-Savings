﻿

namespace Savi_Thrift.Domain.Enums
{
	public enum Occupation
	{
		Farmer,
		Human_Resources,
		Marketing_Specialist,
		Assistant,
		Teacher,
		Engineer,
		IT_Professional,
		Sales_Representative,
		Doctor,
		Accountant,
		Lawyer,
		Banker,
		Entrepreneur,
		Project_Manager,
		Graphic_Designer,
		Others
	}
}
