﻿namespace Savi_Thrift.Domain.Enums
{
	public enum Gender
	{
		Male, Female
	}
}
