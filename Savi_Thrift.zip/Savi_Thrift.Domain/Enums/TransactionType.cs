﻿namespace Savi_Thrift.Domain.Enums
{
    public enum TransactionType
	{
		Credit,
		Debit
	}
}
