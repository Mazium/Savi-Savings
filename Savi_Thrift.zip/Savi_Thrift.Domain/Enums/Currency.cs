﻿

namespace Savi_Thrift.Domain.Enums
{
	public enum Currency
	{
		Naira, Dollar, Euro, Pound
	}
}
