﻿namespace Savi_Thrift.Domain.Entities
{
    public class CloudinarySettings
    {
        public string CloudName { get; set; } = string.Empty;
        public string ApiKey { get; set; } = string.Empty;
        public string ApiSecret { get; set; } = string.Empty;
        public string SectionName { get; set; } = "CloudinarySettings";

    }
}
