﻿namespace Savi_Thrift.Common
{
    public class Class1
    {

    }
}